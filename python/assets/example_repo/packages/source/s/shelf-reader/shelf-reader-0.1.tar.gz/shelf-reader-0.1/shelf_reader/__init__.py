"""
Documentation of package.
"""
import os

__license__ = 'GPL2'
__author__ = 'Austin Macdonald'
__version__ = "0.1"

PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
